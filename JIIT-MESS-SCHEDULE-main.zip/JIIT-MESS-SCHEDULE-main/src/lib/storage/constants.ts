export const STORAGE_KEYS = {
  REVIEWS: 'mess-timetable-reviews',
} as const;