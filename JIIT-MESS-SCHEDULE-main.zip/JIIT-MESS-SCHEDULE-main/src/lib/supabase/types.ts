export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      reviews: {
        Row: {
          id: string
          date: string
          meal_type: string
          rating: number
          comment: string
          author: string
          created_at: string
        }
        Insert: {
          id?: string
          date?: string
          meal_type: string
          rating: number
          comment: string
          author: string
          created_at?: string
        }
        Update: {
          id?: string
          date?: string
          meal_type?: string
          rating?: number
          comment?: string
          author?: string
          created_at?: string
        }
      }
    }
  }
}