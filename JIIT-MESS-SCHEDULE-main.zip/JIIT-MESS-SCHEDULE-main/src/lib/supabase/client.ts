import { createClient } from '@supabase/supabase-js';
import { env } from '../../config/env';
import type { Database } from './types';

export const supabase = env.supabase.url && env.supabase.anonKey
  ? createClient<Database>(env.supabase.url, env.supabase.anonKey)
  : null;