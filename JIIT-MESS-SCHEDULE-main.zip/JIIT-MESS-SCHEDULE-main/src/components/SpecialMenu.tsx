import React from 'react';
import { Star } from 'lucide-react';
import { getSpecialItems } from '../utils/menuUtils';
import { useCurrentMeal } from '../hooks/useCurrentMeal';

export function SpecialMenu() {
  const { todayMeals, specialItems } = useCurrentMeal();

  if (!specialItems.length) return null;

  return (
    <div className="max-w-2xl mx-auto mb-8">
      <div className="bg-gradient-to-r from-yellow-500/20 to-amber-500/20 rounded-lg p-6 border border-yellow-500/20">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Star className="w-6 h-6 text-yellow-400 fill-yellow-400" />
          <h2 className="text-2xl font-bold text-yellow-400">Today's Specials</h2>
        </div>
        <div className="space-y-2">
          {specialItems.map((item, index) => (
            <div 
              key={index}
              className="flex items-center justify-center gap-2 text-lg font-medium text-white"
            >
              <span className="w-2 h-2 rounded-full bg-yellow-400"></span>
              <span>{item}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}