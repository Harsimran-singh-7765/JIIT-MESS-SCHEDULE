// Environment variable validation and access
export const env = {
  supabase: {
    url: import.meta.env.VITE_SUPABASE_URL,
    anonKey: import.meta.env.VITE_SUPABASE_ANON_KEY,
  },
} as const;

// Validate required environment variables
const missingVars = Object.entries(env.supabase).filter(([, value]) => !value);

if (missingVars.length > 0) {
  console.error(
    `Missing required environment variables. Please click the "Connect to Supabase" button to set up your environment.`
  );
}