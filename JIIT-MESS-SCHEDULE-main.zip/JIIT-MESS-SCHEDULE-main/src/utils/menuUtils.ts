import { MealTime } from '../types/timetable';

const SPECIAL_ITEMS = [
  'Paneer',
  'Egg',
  'Chicken',
  'Fish',
  'Special',
  'Biryani',
  'Halwa',
  'Gulab Jamun',
  'Jalebi',
  'Kheer'
] as const;

export function getSpecialItems(meals: MealTime): string[] {
  const allMeals = Object.values(meals).join(' ');
  const specialItems: string[] = [];

  SPECIAL_ITEMS.forEach(keyword => {
    const regex = new RegExp(`\\b${keyword}\\b`, 'i');
    if (regex.test(allMeals)) {
      // Find the complete item containing the keyword
      const mealLines = allMeals.split(',');
      const matchingItem = mealLines.find(line => regex.test(line));
      if (matchingItem) {
        specialItems.push(matchingItem.trim());
      }
    }
  });

  return [...new Set(specialItems)]; // Remove duplicates
}