// Get current day of the week
export function getCurrentDay(): string {
  return new Date().toLocaleDateString('en-US', { weekday: 'long' });
}

// Format date to YYYY-MM-DD
export function getFormattedDate(date: Date = new Date()): string {
  return date.toISOString().split('T')[0];
}

// Check if two dates are the same day
export function isSameDay(date1: Date, date2: Date): boolean {
  return getFormattedDate(date1) === getFormattedDate(date2);
}

// Get start of day for a given date
export function getStartOfDay(date: Date = new Date()): Date {
  const newDate = new Date(date);
  newDate.setHours(0, 0, 0, 0);
  return newDate;
}