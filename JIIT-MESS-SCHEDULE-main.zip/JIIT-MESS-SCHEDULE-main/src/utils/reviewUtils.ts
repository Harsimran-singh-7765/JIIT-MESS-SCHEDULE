import { Review, Reviews } from '../types/review';
import { STORAGE_KEYS } from '../lib/storage/constants';
import { getItem, setItem } from '../lib/storage/localStorage';
import { getFormattedDate } from './dateUtils';

export async function loadReviews(): Promise<Reviews> {
  return getItem<Reviews>(STORAGE_KEYS.REVIEWS) || {};
}

export async function addReview(
  currentReviews: Reviews,
  newReview: Omit<Review, 'id' | 'date'>
): Promise<Reviews> {
  const date = getFormattedDate();
  const id = crypto.randomUUID();
  
  const updatedReviews = {
    ...currentReviews,
    [date]: [
      ...(currentReviews[date] || []),
      { ...newReview, id, date }
    ]
  };

  setItem(STORAGE_KEYS.REVIEWS, updatedReviews);
  return updatedReviews;
}

export function getTodayReviews(reviews: Reviews): Review[] {
  const today = getFormattedDate();
  return reviews[today] || [];
}