import { useMemo } from 'react';
import { timetableData } from '../data/timetable';
import { getCurrentDay } from '../utils/dateUtils';
import { getCurrentMealTime, getNextMealTime } from '../utils/mealTimeUtils';
import { getSpecialItems } from '../utils/menuUtils';
import type { MealTime } from '../types/timetable';

export function useCurrentMeal() {
  const currentDay = getCurrentDay();
  const todayMeals = timetableData[currentDay];
  const currentMealTime = getCurrentMealTime();
  const nextMealTime = currentMealTime || getNextMealTime();
  const specialItems = useMemo(() => getSpecialItems(todayMeals), [todayMeals]);

  const currentMeal = currentMealTime?.toLowerCase() as keyof MealTime | null;
  const nextMeal = nextMealTime.toLowerCase() as keyof MealTime;

  return {
    currentDay,
    todayMeals,
    currentMealTime,
    nextMealTime,
    currentMeal,
    nextMeal,
    specialItems,
  };
}